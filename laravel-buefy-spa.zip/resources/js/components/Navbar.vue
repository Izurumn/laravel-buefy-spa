    <template>
      <nav class="level is-hidden-mobile">
        <div class="level-item has-text-centered">
            <div>
              <router-link :to="{ name: 'welcome' }">
              <p class="heading">нүүр хэсэг</p>
              <p class="title">Эхлэл</p>
              </router-link>
            </div>
          </div>
          <div class="level-item has-text-centered">
    <div>
      <router-link :to="{ name: 'shop' }">
      <p class="heading">ранк авах</p>
      <p class="title">Дэлгүүр</p>
      </router-link>
    </div>
  </div>
        <p class="level-item has-text-centered">
          <img src="/images/logo.png" alt="" style="height: 200px;">
        </p>
        <div class="level-item has-text-centered">
            <div>
              <p class="heading">шийтгэлүүд</p>
              <p class="title">Бан жагсаалт</p>
            </div>
          </div>
          <div class="level-item has-text-centered">
            <div>
            <p class="heading">заавар зөвлөгөө</p>
            <p class="title">Вики</p>
          </div>
        </div>
      </nav>
    </template>
<script>
import $ from 'jquery'
export default {
mounted: function(){
  $(document).ready(function() {

    // Check for click events on the navbar burger icon
    $(".navbar-burger").click(function() {

        // Toggle the "is-active" class on both the "navbar-burger" and the "navbar-menu"
        $(".navbar-burger").toggleClass("is-active");
        $(".navbar-menu").toggleClass("is-active");

    });
  });
}
}
</script>

<template>
  <div class="container" style="padding:25px;">
    <article class="message">
      <div class="message-header">
        <p>Худалдаж авахад анхаарах зүйлс</p>
      </div>
      <div class="message-body">
        Minecraft username буюу Nexus серверт тоглодог нэр юм.
        <br>
        Ранк авах гэж байгаа бол цааш үргэлжлүүлнэ үү...
            </div>
    </article>
    <article v-show="errors" class="message">
      <div class="message-body" style="color:red;">
        Таны утасны дугаар эсхүл username буруу байна.
        <br>
            </div>
    </article>
    <div class="columns">
      <div class="column">
    <div class="field">
      <label class="label">Minecraft username</label>
      <div class="control">
        <input class="input" v-model="username" type="text" placeholder="Minecraft username">
      </div>
    </div>
    <div class="field">
      <label class="label">Холбоо барих утас</label>
      <div class="control">
        <input class="input" v-model="number" type="text" placeholder="99******">
      </div>
    </div>
    <div class="field is-grouped">
      <div class="control">
        <button class="button is-link" @click="create()">Худалдаж авах</button>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card" style="max-width: 250px;">

      <div class="card-content">
        <div class="content">
        <b>Айтм нэр: </b>{{item.name}}
          <br>
          <b>Үнэ:</b> {{item.price}}₮
          <br>
          <b>Хөнгөлөлттэй куфон:</b>
          <br>
          <input class="input" type="text" placeholder="Хөнгөлөлттэй куфон">
          <br>
          <hr>
          Нийт төлөх үнэ: {{item.price}}₮
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data() {
    return {
      item: [],
      price: '',
      username: '',
      number: '',
      price: '',
      order: [],
      hash: '',
      errors: false
    }
  },
  created() {
    let uri = 'api/item/' + this.$route.params.id;
    this.axios.get(uri).then(response => {
      this.item = response.data.item;
    });
  },
  methods: {
    create() {

      if(this.number.length==8 && this.username.length>4) {
      this.gobit()
      }
      else {
        this.errors = true
      }
    },
    gobit() {
      let uri = 'api/order/';
      let formData = new FormData()
       formData.append('price', this.item.price)
       formData.append('username', this.username)
       formData.append('number', this.number)
       formData.append('items_id', this.item.id)
       axios.post(uri, formData)
       .then(response => {
         this.order = response.data
         this.$cookie.set('order', this.order, { expires: '60m' });
         this.$router.push('/buy/' + this.order);
        })
    }
  }
}
</script>

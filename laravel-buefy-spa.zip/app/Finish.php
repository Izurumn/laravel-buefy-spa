<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Finish extends Model
{
  protected $table='finishes';
  protected $fillable = ['items_id', 'orders_id'];
}
